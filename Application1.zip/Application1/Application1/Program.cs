﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application1
{
    class MyGenericArray<T>
    {
        
        private T[] genericArray; // definicja generycznej tablicy

        static MyGenericArray()  //Konstruktor statyczny
        {
            
        }

        public MyGenericArray(int size)  // Konstruktor gdzie parametr to rozmiar tablicy
        {
            genericArray = new T[size + 1]; // ustalenie rozmiaru tablicy generycznej
        }
        
        
        public T getGenericItem(int index)  // Metoda pozwalająca na zwrócenie dowolnego typu danych
        {
            return genericArray[index];
        }


        public void setGenericValue(int index, T value)  // Metoda pozwalająca na ustawienie dowolnego typu danych
        {
            genericArray[index] = value;
        }

        //-------------------------------------- List Implementation ----------------------- To nie dziala
        private List<T> lista;
        public MyGenericArray(T value, int index)
        {
            lista = new List<T>(index);
        }

        //public void Lista(T value)
        //{
        //    lista = new List<T>();
        //}
        public void DajDane(int n, T value)
        {
 
            lista.Add(value);


        }
        public void ZwrocDane()
        {
            foreach(var p in lista)
            {
                Console.WriteLine(p);
            }
        }
        //---------------------------------------------------------------------------------
        
    }
    //------------------------------------------ Od tego momentu ta kopia
    class MyGenericArrayCopy<T1>
    {
        public MyGenericArray<T1> mga;
        public MyGenericArrayCopy()
        {
            MyGenericArrayCopy<T1> tempA = new MyGenericArrayCopy<T1>();
            tempA.mga = this.mga;
            return tempA;
        }
    }
    
    //------------------------------Przyklad kopi na takich klasach a my musimy na tamtym
    class B
    {
        public string slowo;
    }

    class A
    {
        public int liczba;
        public B objB;
        public A()
        {
            objB = new B();
        }
        public A GlebokaKopia()
        {
            A tempA = new A();
            tempA.liczba = this.liczba;
            tempA.objB.slowo = this.objB.slowo;
            return tempA;
        }
    }


    class Program
    {

        static void Main(string[] args)
        {
            
            MyGenericArray<int> intArray = new MyGenericArray<int>(5);   // Tablica liczb całkowitych oraz jej wypełnienie
            for (int i = 0; i < 5; i++)
            {
                intArray.setGenericValue(i, i * 3);
            }
            
            for (int i = 0; i < 5; i++)  // Wypisanie wszystkich danych
            {
                Console.WriteLine("Liczba: {0}", intArray.getGenericItem(i));
            }
            

            MyGenericArray<char> charArray = new MyGenericArray<char>(5);  // Ta sama generyczna klasa ale inny typ danych
            for (int i = 0; i < 5; i++)
            {
                charArray.setGenericValue(i, (char)(i + 97));
            }
            
            for (int i = 0; i < 5; i++) // Wypisanie wszystkich danych
            {
                Console.WriteLine(charArray.getGenericItem(i));
            }
            Console.ReadKey();
            
            
            //----------------- Przyklad listy tylko dla dzialania bez klas wyzej
            //Console.WriteLine("List Implementation:");
            //List<string> lista = new List<string>();
            //lista.Add("Ala");
            //lista.Add("Kaja");
            //foreach(var k in lista)
            //{
            //    Console.WriteLine(k);
            //}

            //-- Implementation List  ---
            //Console.WriteLine("Inne:");


            //MyGenericArray<int> intArrayList = new MyGenericArray<int>(5);
            //for(int i=0; i<5; i++)
            //{
            //    intArrayList.DajDane(i, i * 2);
            //}



            //intArrayList.ZwrocDane();




            //MyGenericArray<int> genericArrayCopy = new MyGenericArray<int>(5);
            //genericArrayCopy = intArray;
            //for(int i=0; i<5; i++)
            //{
            //    Console.WriteLine(genericArrayCopy.getGenericItem(i));
            //}


            A obiekt1 = new A();
            A obiekt2 = new A();

            obiekt1.liczba = 5;
            obiekt1.objB.slowo = "kurczak";

            obiekt2 = obiekt1.GlebokaKopia(); 

            Console.WriteLine("obiekt2.liczba=" + obiekt2.liczba);
            Console.WriteLine("obiekt2.objB.slowo=" + obiekt2.objB.slowo);

            if (Object.ReferenceEquals(obiekt1.objB, obiekt2.objB))
                Console.WriteLine("Referencje odwołuja się do tego samego obiektu");
            else
                Console.WriteLine("Referencje nie odwołuja się do tego samego obiektu"); //<-
        


        Console.ReadKey();
        }
    }
}
