#include <iostream> //in and output libary
#include <cmath> // math libary for rand
#include <time.h> // time libary for time(NULL)
#include <ctime>
#include <stdlib.h>
using namespace std;

struct character
{
	int posX;
	int posY;
	char symbol;
	int hp;
}player;// struct for the player




int main()
{


	const char HEIGHT = 18, WIDTH = 18; // the maze width and height
	bool update = false; // boolean to control when the map needs to be updated
	char move_key = 'd';

	player.posX = 1;
	player.posY = 1;
	player.symbol = 'O';

	player.hp = 3; // players different attributes


	unsigned char maze[WIDTH][HEIGHT] =
	{
		'#','#','#','#','#','#','#','#','#','#','#','#','#','#','#','#','#','#',
		'#',' ','#',' ',' ',' ','#','#','#',' ',' ','#','#',' ','#',' ','#','#',
		'#',' ','#','#',' ','#','#',' ','#',' ','#','#',' ',' ','#',' ','#',' ',
		'#',' ','#','#',' ',' ',' ',' ','#',' ','#','#',' ','#','#',' ',' ',' ',
		'#',' ',' ',' ',' ','#',' ','#',' ',' ',' ',' ',' ','#','#','#',' ','#',
		'#',' ','#','#',' ','#',' ','#','#',' ','#','#',' ',' ','#',' ',' ','#',
		'#','#','#',' ',' ','#',' ','#','#',' ',' ','#',' ','#','#',' ','#','#',
		'#','#',' ',' ','#','#','#','#',' ',' ','#',' ',' ','#','#',' ','#','#',
		'#','#','#',' ','#','#','#','#','#',' ','#',' ','#','#','#',' ','#','#',
		'#',' ','#',' ',' ',' ','#','#','#',' ',' ',' ','#',' ','#',' ','#','#',
		'#',' ','#','#',' ','#','#',' ','#',' ','#','#',' ',' ','#',' ','#','#',
		'#',' ','#','#',' ',' ',' ',' ',' ',' ','#','#',' ','#','#',' ',' ','#',
		'#',' ',' ',' ',' ','#',' ','#','#',' ','#',' ',' ','#','#','#',' ','#',
		'#',' ','#','#',' ','#',' ','#','#',' ','#','#',' ',' ',' ',' ',' ','#',
		'#','#','#',' ',' ','#',' ','#','#',' ',' ','#',' ','#','#',' ','#','#',
		'#','#','#','#',' ','#','#','#','#',' ','#',' ',' ','#','#',' ','#','#',
		'#','#','#',' ',' ',' ',' ','#','#',' ',' ',' ','#','#','#',' ','#','#',
		'#','#','#','#','#','#','#','#','#','#','#','#','#','#','#','#','#','#',
	};
	cout << "press (d) (a) (w) or (s) and then return to start the game\n";
	cout << "presse (Q) then return to quit the game\n";



	while (move_key != 'q') // as long as move_key is not q then this loop will run and thereby everysingle little thing, which is happening in the maze
	{

		srand(time(NULL)); // random seed based on some time thingy
		int random_move = rand() % 2 + 1; // random number between 1 and 2

		cin >> move_key;
		update = true;  // map updates

		if (update == true) // if map is updated, then the enemies will be printed onto the map and the player
							// the maze will be created by a nested for loop, but the x and y are at the wrong places in order to create the map I have "painted" with #
							// the health will be outputted, so the gamer can see the life of the "player"
							// update stopped
		{
			system("CLS");



			maze[player.posX][player.posY] = player.symbol;


			for (int y = 0; y<HEIGHT; y++)
			{
				cout << endl;
				for (int x = 0; x<WIDTH; x++)
				{
					cout << maze[x][y];
				}
			}
			cout << endl << endl << "    health: " << player.hp << endl << "____________________\n \n";
			update = false;
		}

		switch (move_key) // different key pressed in order to move the player and to see if the player collides with a # or an enemy
						  // it will be printed out the "player's" location, because the game are asynchron
						  // it will also be printed if the player hits a wall
		{
		case 'w':
			update = true;
			if (maze[player.posX][player.posY - 1] != '#')
			{
				maze[player.posX][player.posY] = ' ';
				player.posY--;



				cout << player.posX << " " << player.posY << endl;
			}
			else
				cout << "  you hit a wall";
			break;

		case 's':
			update = true;
			if (maze[player.posX][player.posY + 1] != '#')
			{
				maze[player.posX][player.posY] = ' ';
				player.posY++;



				cout << player.posX << " " << player.posY << endl;
			}
			else
				cout << "  you hit a wall";
			break;

		case 'a':
			update = true;
			if (maze[player.posX - 1][player.posY] != '#')
			{
				maze[player.posX][player.posY] = ' ';
				player.posX--;



				cout << player.posX << " " << player.posY << endl;
			}
			else
				cout << "  you hit a wall";

			break;

		case 'd':
			update = true;
			if (maze[player.posX + 1][player.posY] != '#')
			{
				maze[player.posX][player.posY] = ' ';
				player.posX++;



				cout << player.posX << " " << player.posY << endl;
			}
			else
				cout << "  you hit a wall";
			break;
		}







	}// while loop ends here.
	return 0;

}
