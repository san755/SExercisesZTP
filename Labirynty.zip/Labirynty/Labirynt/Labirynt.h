#ifndef LABIRYNT_H_INCLUDED
#define LABIRYNT_H_INCLUDED
#include<time.h>
class labirynt
{
      private:
        int pozX, pozY, maxX, maxY, wyjscieX,wyjscieY,ilePoprzenich;
        int **tablicaPoprzednich;
        char **lab;
        bool czyLabirynt, czyWyjscie;

        int szukajNastepny(int [][2],int, int);
        void przesun(int [],int[][2],int, int, int);
        bool sprawdzSkrzyzowanie(int [][2], int, int, int);

        void tworzTablicePoprzednich(int,int);
        void usunTablicePoprzednich();

        void usunPunktPowrotu(int);

      public:
        labirynt();
        void pokazLabirynt();
        bool wskazStart();
        int szukajDrogi(int,int);
        void pokazWyjscie();
        ~labirynt();
};

#endif // LABIRYNT_H_INCLUDED
