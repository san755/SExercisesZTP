#include <iostream>
#include <conio.h>
#include "Labirynt.h"
#include "Labirynt.cpp"
using namespace std;

int main(void)
{
  bool setXY=false;
  labirynt lab;
  int wynikLab;
  while(!setXY)
  {
      setXY=lab.wskazStart();
      //system("cls");
  }
  lab.pokazLabirynt();
  wynikLab=lab.szukajDrogi(-1,-1);
  lab.pokazLabirynt();
  if(wynikLab==1)
  {
    cout<<"WYJSCIE "<<endl;
    lab.pokazWyjscie();
  }
  else
    cout<<"NIE MOZNA OSIAGNAC WYJSCIA LABIRYNTU "<<endl;
  getch();

  return 1;
}
