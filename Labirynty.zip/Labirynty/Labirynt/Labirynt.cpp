#include <iostream>
#include <fstream>
#include <conio.h>
#include <time.h>
#include <cstdlib>
#include "Labirynt.h"
using namespace std;

labirynt::labirynt()
{
  maxX=20;
  maxY=20;
  fstream plik;
  char t;
  czyLabirynt=true;
  plik.open("F:\DellPulpit\Sielski zadania\Labirynt\lab2.txt",ios::in);
  if(!plik)
  {
     czyLabirynt=false;
     cout<<"BLAD ZALADOWANIA PLIKU LABIRYNTU"<<endl;
  }
  if(czyLabirynt)
  {
      int i=0,j=0;
      char t;
      lab = new char*[maxY];
      lab[0]=new char[maxX];
      while(!plik.eof())
      {
        plik.get(t);
        if((int)t==10)
        {
           i++;j=0;
           lab[i]=new char[maxX];
           continue;
        }
        lab[i][j]=t;
        j++;
      }
  }
  plik.close();
  czyWyjscie=false;
}

void labirynt::pokazLabirynt()
{
   if(!czyLabirynt)
   {
        cout<<"NIE WCZYTANO PLIKU NIE MA CZEGO OGLADAC"<<endl;
        return;
   }
   int i,j;
   char t;
   for(i=0;i<maxX;i++)
   {
      for(j=0;j<maxX;j++)
      {
          t=lab[i][j];
          if(t=='2')
           cout <<" ";//(char)254;
          else if(t=='1')
           cout <<(char)177;
          else if(t=='3')
           cout <<(char)248;
          else if(t=='4')
           cout <<(char)227;
          else
            cout <<t;
      }
      cout<<"\n";
  }
  cout<<"*******LEGENDA********"<<endl;
  cout<<(char)177<<" - SCIANA"<<endl;
  cout<<(char)248<<" - WYJSCIE"<<endl;
  cout<<(char)227<<" - START"<<endl;
}

bool labirynt::wskazStart()
{

  if(!czyLabirynt)
  {
       cout<<"NIE WCZYTANO PLIKU NIE MA GDZIE I CZEGO SZUKAC"<<endl;
       return false;
  }
  int x,y;
  cout<<"Wskaz punt startu okreslajac jego wspolzedne X i Y"<<endl;
  cout<<"Podaj wspolzedna X: ";
  cin>>x;
  cout<<"Podaj wspolzedna Y: ";
  cin>>y;
  if((x-1<0 or x-1>maxX-1) or (y-1<0 or y-1>maxY-1))
  {
    cout<<"PODALES NIEWLASCIWY ZAKRES"<<endl;
    getch();
    return false;
  }
  else
  {
      if(lab[y-1][x-1]=='2')
      {
         pozX=x-1;
         pozY=y-1;
         lab[y-1][x-1]='4';
         return true;
      }
      else
      {
         cout<<"TRAFILES W W SCIANE"<<endl;
         getch();
         return false;
      }
  }

}
int labirynt::szukajDrogi(int x,int y)
{
     static int biezX, biezY, wynik;
     int mozliweRuchy[4][2]={{1,0},{0,1},{-1,0},{0,-1}};
     int nstRuch, pozNstRuch[2], wywolanieX, wywolanieY;
     if(x==-1 && y ==-1)
     {
        biezX=pozX;
        biezY=pozY;
        tablicaPoprzednich = new int*[1];
        tablicaPoprzednich[0] = new int[2];
        tablicaPoprzednich[0][0] = biezX;
        tablicaPoprzednich[0][1] = biezY;
        ilePoprzenich=1;
        wynik=0;
     }
     else
     {
        biezX=x;
        biezY=y;
     }
     nstRuch=szukajNastepny(mozliweRuchy,biezX,biezY);
     if (czyWyjscie)
     {
      wynik = 1;
     }
     while(!wynik)
     {
         if(nstRuch<4)
         {
            przesun(pozNstRuch,mozliweRuchy,biezX,biezY,nstRuch);
            if(sprawdzSkrzyzowanie(mozliweRuchy,pozNstRuch[0],pozNstRuch[1],1))
            {
                tworzTablicePoprzednich(pozNstRuch[0],pozNstRuch[1]);
                ilePoprzenich++;

            }
            wywolanieX=pozNstRuch[0];
            wywolanieY=pozNstRuch[1];
         }
         else
         {
           int szukX,szukY;
           while(ilePoprzenich>0)
           {
                szukX=tablicaPoprzednich[ilePoprzenich-1][0];
                szukY=tablicaPoprzednich[ilePoprzenich-1][1];
                if(sprawdzSkrzyzowanie(mozliweRuchy,szukX,szukY,0))
                {
                    wywolanieX = szukX;
                    wywolanieY = szukY;
                    break;
                }
                else
                {
                    usunPunktPowrotu(ilePoprzenich);
                    ilePoprzenich--;
                }
           }
         }
         if(ilePoprzenich<1)
            wynik =-1;
         else
         {
           pokazLabirynt();
           //system("cls");
           szukajDrogi(wywolanieX,wywolanieY);
         }

     }
     return wynik;
}
int labirynt::szukajNastepny(int ruchy[][2],int x, int y)
{
    int ruch=0, sprX, sprY, ruchTmp[4], z=0, zmienna;
    while (ruch<4)
    {
       sprX=x + ruchy[ruch][0];
       sprY=y + ruchy[ruch][1];
       if((sprX<0 || sprX>maxX)|| (sprY<0 || sprY>maxY))
       {
         ruch++;
         continue;
       }
       if(lab[sprY][sprX]=='3')
       {
          wyjscieX = sprX;
          wyjscieY = sprY;
          czyWyjscie=true;
          break;
       }
       if(lab[sprY][sprX]=='2')
       {
          z++;
          ruchTmp[z-1]=ruch;

       }
       ruch++;
    }
    if(z==0)
        return ruch;
    srand(time(NULL));
    zmienna=(rand()%z)  ;
    return ruchTmp[zmienna];
}
void labirynt::przesun(int tablica[],int ruchy[][2], int x, int y, int index)
{
      tablica[0]=x + ruchy[index][0];
      tablica[1]=y + ruchy[index][1];
      lab[tablica[1]][tablica[0]] = '.';

}
bool labirynt::sprawdzSkrzyzowanie(int tablica[][2],int x, int y, int wielkosc)
{
     int mozliwosci = 0;
     char z;
     for(int i=0;i<4;i++)
     {
       z=lab[y + tablica[i][1]][x + tablica[i][0]];
       if( z == '2' || z == '3')
          mozliwosci++;
     }

     if(mozliwosci>wielkosc)
         return true;
     return false;

}

void labirynt::tworzTablicePoprzednich(int x, int y)
{
     int **tmpTP;

     tmpTP = new int*[ilePoprzenich];

     for(int i=0;i<ilePoprzenich;i++)
     {
        tmpTP[i]=new int[2];
        tmpTP[i][0] = tablicaPoprzednich[i][0];
        tmpTP[i][1] = tablicaPoprzednich[i][1];
     }

     usunTablicePoprzednich();
     tablicaPoprzednich = new int*[ilePoprzenich+1];
     for(int i=0;i<ilePoprzenich;i++)
     {
        tablicaPoprzednich[i]=new int[2];
        tablicaPoprzednich[i][0] = tmpTP[i][0];
        tablicaPoprzednich[i][1] = tmpTP[i][1];
     }
     tablicaPoprzednich[ilePoprzenich]=new int[2];
     tablicaPoprzednich[ilePoprzenich][0]=x;
     tablicaPoprzednich[ilePoprzenich][1]=y;

     for(int i=0;i<ilePoprzenich;i++)
     {
        delete [] tmpTP[i];
     }
     delete [] tmpTP;

}
void labirynt::usunTablicePoprzednich()
{
  for(int i=0;i<ilePoprzenich;i++)
  {
      delete [] tablicaPoprzednich[i];
  }
  delete [] tablicaPoprzednich;
}
void labirynt::usunPunktPowrotu(int index)
{
  delete [] tablicaPoprzednich[index-1];
}
void labirynt::pokazWyjscie()
{
 cout<<"WSPOLZEDNE WYJSCIA"<<endl;
 cout<<"X="<<wyjscieX+1<<endl;
 cout<<"Y="<<wyjscieY+1<<endl;
}

labirynt::~labirynt()
{
    if(!czyLabirynt)
        return;
    usunTablicePoprzednich();
    for(int i=0;i<maxY;i++)
        delete []  lab[i];
    delete [] lab;
}
