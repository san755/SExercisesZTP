#include <iostream>

#include <conio.h>


using namespace std;


int pozycja_x = 0;

int pozycja_y = 0;

bool koniec = false;

char ruch;

char gracz = 'x';


char mapa[10][10]=        //mapa[y-liczba "wersow"][x-liczba znakow w kazdym wersie]        Przykladowa mapa

{

    ' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',    //y=0

    ' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',    //y=1

    ' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',    //y=2

    ' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',    //y=3

    ' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',    //y=4

    ' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',    //y=5

    ' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',    //y=6

    ' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',    //y=7

    ' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',    //y=8

    ' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',    //y=9

};


char mapa1[10][10]=

{

    ' ' , ' ' , ' ' , '|' , '|' , '-' , '-' , '-' , '-' , '\\' ,

    '|' , '-' , ' ' , '-' , '-' , ' ' , ' ' , '=' , ' ' , '|' ,

    '|' , ' ' , ' ' , ' ' , '|' , ' ' , '=' , ' ' , ' ' , '|' ,

    '|' , ' ' , '-' , ' ' , '|' , '=' , ' ' , ' ' , ' ' , '|' ,

    '|' , ' ' , '|' , ' ' , '|' , '-' , ' ' , ' ' , ' ' , '|' ,

    '|' , ' ' , '|' , ' ' , ' ' , ' ' , ' ' , ' ' , '-' , '|' ,

    '|' , ' ' , '|' , ' ' , ' ' , '|' , ' ' , ' ' , ' ' , '|' ,

    '|' , ' ' , '-' , ' ' , '-' , ' ' , ' ' , '-' , ' ' , '|' ,

    '|' , ' ' , ' ' , ' ' , ' ' , ' ' , '-' , ' ' , ' ' , 'O' ,

    '\\' , '-' , '-' , '-' , '-' , '-' , '-' , '-' , '-' , '/'

};

char mapa2[20][20]=

{

    ' ',' ','-','-','-','-','-','-','-','-','-','-','O','-','-','-','-','-','-','\\',

    '|',' ',' ','=',' ',' ',' ',' ',' ',' ',' ',' ',' ','/','/','/',' ',' ',' ','|',

    '|','=',' ','=',' ',' ','=','=','=','=',' ','/',' ',' ',' ',' ','/',' ',' ','|',

    '|',' ',' ',' ','/',' ',' ',' ',' ',' ','/','/','/',' ','/','/',' ','/',' ','|',

    '|',' ','=',' ','/',' ',' ','=',' ',' ',' ',' ',' ','/',' ',' ','/',' ',' ','|',

    '|',' ','=',' ','/',' ',' ','=','/',' ',' ','=',' ','/',' ',' ','/',' ',' ','|',

    '|',' ','=',' ','/','=','/',' ',' ','/',' ','=','=',' ',' ',' ',' ',' ',' ','|',

    '|',' ','=',' ',' ',' ','=',' ','/',' ',' ','=',' ',' ','/',' ','/',' ','=','|',

    '|',' ','=','/',' ',' ','=','=',' ','=',' ',' ',' ','=',' ','/',' ',' ',' ','|',

    '|',' ',' ','/','/',' ',' ','=',' ','=','=',' ','=',' ','=',' ','=',' ',' ','|',

    '|','=',' ',' ','/','/',' ','=',' ',' ',' ',' ',' ','|','|',' ',' ',' ',' ','|',

    '|','=',' ',' ',' ','/',' ','=','=',' ','|','\\',' ',' ',' ',' ',' ',' ',' ','|',

    '|',' ','=',' ',' ','/',' ',' ','/','|',' ',' ','|',' ',' ','|','=',' ',' ','|',

    '|',' ','=',' ',' ','/','/','/','/',' ',' ','|',' ',' ',' ',' ',' ',' ',' ','|',

    '|',' ',' ','=',' ',' ','|','|',' ',' ','+',' ',' ','|',' ',' ','|','=',' ','|',

    '|','|','|',' ','=',' ',' ','|',' ',' ',' ',' ',' ',' ','=',' ',' ',' ',' ','|',

    '|',' ',' ',' ','|',' ',' ',' ',' ','+',' ','|',' ',' ',' ',' ','=',' ','=','|',

    '|','|','|',' ','|','|','|','+','+',' ','+',' ','|',' ','=','=',' ',' ',' ','|',

    '|',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','|',' ',' ',' ',' ',' ',' ',' ','|',

    '\\','-','-','-','-','-','-','-','-','-','-','-','-','-','-','-','-','-','-','/',

};


void gra1();

void gra2();


//================================================================================


int main()

{


    int wybor;

    cout<<"       Labirynt      \n\n 1.Start\n 2.Wybierz gracza\n 3.Sterowanie\n 4.Wyjscie\n";

    cin>>wybor;

    switch(wybor)

    {

    case 1: gra1(); break;

    case 2: cout<<"Podaj znak gracza\n"; gracz=_getch(); main(); break;

    case 3: cout<<"w,s,a,d - poruszanie sie\nq - wyjscie\n\n\ Wcisnij dowolny znak aby powrocic do menu";_getch();main();


    default: cout<<"Nie ma takiej opcji";_getch();main();

    }

}


void gra1()

{

    pozycja_x=0;

    pozycja_y=0;

    koniec=false;

    while(!koniec)

    {


        for(int y=0; y<10; y++)

        {

            for(int x=0; x<10; x++)

            {

                if(x==pozycja_x && y==pozycja_y)

                {

                    cout<<gracz;

                }//if

                else

                {

                    cout<<mapa1[y][x];

                }//else

            }//for

            cout<<"\n";

        }//for

        ruch=_getch();

        switch(ruch)

        {

        case 'a': if(mapa1[pozycja_y][pozycja_x - 1]==' ' || mapa1[pozycja_y][pozycja_x - 1]=='O')\

                      --pozycja_x; break;

        case 'd': if(mapa1[pozycja_y][pozycja_x + 1]==' ' || mapa1[pozycja_y][pozycja_x + 1]=='O')\

                      ++pozycja_x; break;

        case 'w': if(mapa1[pozycja_y - 1][pozycja_x]==' ' || mapa1[pozycja_y - 1][pozycja_x]=='O')\

                      --pozycja_y; break;

        case 's': if(mapa1[pozycja_y + 1][pozycja_x]==' ' || mapa1[pozycja_y + 1][pozycja_x]=='O')\

                      ++pozycja_y; break;

        case 'q': main(); break;

        }//switch

        if(mapa1[pozycja_y][pozycja_x]=='O')

        {

        koniec = true;

        }//if

    }//while

    gra2();

}


void gra2()

{

    pozycja_x=0;

    pozycja_y=0;

    koniec=false;

    while(!koniec)
    {
        for(int y=0; y<20; y++)
        {
            for(int x=0; x<20; x++)
            {
                if(x==pozycja_x && y==pozycja_y)
                {
                    cout<<gracz;

                }//if
                else
                {
                    cout<<mapa2[y][x];
                }//else
            }//for
            cout<<"\n";
        }//for

        ruch=_getch();

        switch(ruch)
        {

        case 'a': if(mapa2[pozycja_y][pozycja_x - 1]==' ' || mapa2[pozycja_y][pozycja_x - 1]=='O')\

                      --pozycja_x; break;

        case 'd': if(mapa2[pozycja_y][pozycja_x + 1]==' ' || mapa2[pozycja_y][pozycja_x + 1]=='O')\

                      ++pozycja_x; break;

        case 'w': if(mapa2[pozycja_y - 1][pozycja_x]==' ' || mapa2[pozycja_y - 1][pozycja_x]=='O')\

                      --pozycja_y; break;

        case 's': if(mapa2[pozycja_y + 1][pozycja_x]==' ' || mapa2[pozycja_y + 1][pozycja_x]=='O')\

                      ++pozycja_y; break;

        case 'q': main(); break;

        }//switch

        if(mapa2[pozycja_y][pozycja_x]=='O')
        {
            koniec = true;
        }//if

    }//while

    main();

}
